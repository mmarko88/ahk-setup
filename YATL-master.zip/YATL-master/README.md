YATL
====

A todo list written in autohotkey

gui and inspiration from: [YATL](http://www.autohotkey.com/board/topic/35114-yatl-yet-another-todo-list/)

![screenshot](http://i.imgur.com/YtG2zHA.png)
