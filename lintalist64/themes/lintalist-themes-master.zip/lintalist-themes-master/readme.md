﻿# Themes for Lintalist

Download a zipped theme file and unpack to 'lintalist\themes\' - some themes may include  
alternative icons in the `icons` sub-folder. Unpack while preserving the folder structure.

More information about themes and how to create your own:  
https://github.com/lintalist/lintalist/blob/master/themes/Themes.md

If you have a theme, feel free to open an Issue or make a Pull request.
