
# 2019-04-07
2019-04-07 21:08:41> INFO....: Logging started with log level 5
2019-04-07 21:08:41> INFO....: Building bug.n started
2019-04-07 21:08:41> DEBUG...: **compile**: Variable set, source      -> `C:\Users\jn\Downloads\bug.n.git\tools\..\src\Main.ahk`, the file does exist.
2019-04-07 21:08:41> DEBUG...: **compile**: Variable set, destination -> `C:\Users\jn\Downloads\bug.n.git\tools\..\bugn.exe`, the file does **not** exist.
2019-04-07 21:08:41> DEBUG...: **compile**: Variable set, customIcon  -> `C:\Users\jn\Downloads\bug.n.git\tools\..\src\logo.ico`, the file does exist.
2019-04-07 21:08:41> DEBUG...: **compile**: Variable set, compiler    -> `C:\Program Files\AutoHotkey\Compiler\Ahk2Exe.exe`, the file does exist.
2019-04-07 21:08:41> DEBUG...: **compile**: Variable set, useMpress   -> `0`
2019-04-07 21:08:45> INFO....: Compiling the script to an executable finished.
2019-04-07 21:08:45> DEBUG...: **createCheatSheet**: Variable set, source    -> `C:\Users\jn\Downloads\bug.n.git\tools\..\doc\Default_hotkeys.md`, the file does exist.
2019-04-07 21:08:45> DEBUG...: **createCheatSheet**: Variable set, destDir   -> `C:\Users\jn\Downloads\bug.n.git\tools\..\doc\Cheat_sheet`, the file does exist.
2019-04-07 21:08:45> DEBUG...: **createCheatSheet**: Variable set, converter -> `C:\Users\jn\AppData\Roaming\..\Local\Pandoc\pandoc.exe`, the file does exist.
2019-04-07 21:08:45> DEBUG...: **createCheatSheet**: Converting source `C:\Users\jn\Downloads\bug.n.git\tools\..\doc\Default_hotkeys.md` to destination `C:\Users\jn\Downloads\bug.n.git\tools\..\doc\Cheat_sheet\cheat_sheet.md`.
2019-04-07 21:08:45> DEBUG...: **createCheatSheet**: Running command `C:\Users\jn\AppData\Roaming\..\Local\Pandoc\pandoc.exe -s -o C:\Users\jn\Downloads\bug.n.git\tools\..\doc\Cheat_sheet\cheat_sheet.html --section-divs -c reset.css -c cheat_sheet.css C:\Users\jn\Downloads\bug.n.git\tools\..\doc\Cheat_sheet\cheat_sheet.md`
2019-04-07 21:08:45> INFO....: Creating the cheat sheet finished.
2019-04-07 21:08:45> ........: Building bug.n finished
