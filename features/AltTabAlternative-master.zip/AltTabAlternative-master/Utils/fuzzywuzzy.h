#pragma once

#include <iostream>

double ratio(const std::string& s1, const std::string& s2);

double partial_ratio(const std::string& s1, const std::string& s2);
